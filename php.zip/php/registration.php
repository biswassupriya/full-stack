<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<?php
require('db.php');

// If form submitted, insert values into the database.

if (isset($_REQUEST['your_email'])){
        // removes backslashes
	$firstname = stripslashes($_REQUEST['first_name']);
        //escapes special characters in a string
	$firstname = mysqli_real_escape_string($con,$firstname);
	$lastname = stripslashes($_REQUEST['last_name']);
	$lastname = mysqli_real_escape_string($con,$lastname);
	$dob = stripslashes($_REQUEST['Date-of-Birth']);
            //escapes special characters in a string
    $dob = mysqli_real_escape_string($con,$dob);
    $youremail = stripslashes($_REQUEST['your_email']);
    $youremail = mysqli_real_escape_string($con,$youremail);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con,$password);
    $password = md5($password);
    $address = stripslashes($_REQUEST['Address']);
    $address = mysqli_real_escape_string($con,$address);
    $address2 = stripslashes($_REQUEST['Address2']);
    $address2 = mysqli_real_escape_string($con,$address2);
    $postcode = stripslashes($_REQUEST['Postcode']);
    $postcode = mysqli_real_escape_string($con,$postcode);

   $query = "INSERT into `userlogin` (firstName, LastName,DateOfBirth, Email, Password, Address, City, PostCode)
VALUES ('$firstname', '$lastname', '$dob', '$youremail', '$password', '$address', '$address2', '$postcode')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'>
<h3>You are registered successfully.</h3>
<br/>Click here to <a href='../login.html'>Login</a></div>";
        }
    }else{
?>
<section>
		<div>
			<form>
			<h2 id="update">User Registration and Update Form </h2>
			     <div class="form-group">
							<div class="form-row form-row-1">
								<label id="a" for="first_name">First Name</label>
								<input  type="text" name="first_name" id="first_name" class="input-text">
							</div>
							<div class="form-row form-row-1">
								<label id="b" for="last_name">Last Name</label>
								<input  type="text" name="last_name" id="last_name" class="input-text">
							</div>
					 <div class="form-row">
						 <label id="c" class="Date_of_Birth">Date Of Birth</label>
						 <input id="mu" type="date" name="Date-of-Birth"  class="input-text">
					 </div>
						<div class="form-row">
							<label id="d" for="your_email">Your Email</label>
							<input id="su" type="text" name="your_email" id="your_email" class="input-text" required pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}">
						</div>
						<div class="form-group">
							<div class="form-row form-row-1 ">
								<label id="e" >Password</label>
								<input id="me" type="password" name="password" class="input-text" required>
							</div>
							<div class="form-row form-row-1">
								<label id="f" >Comfirm Password</label>
								<input id="ea" type="password" name="comfirm_password" id="comfirm_password" class="input-text" required>
							</div>
							<div class="form-row">
								<label id="g">Address</label>
								<input id="ku" type="text" name="Address"  class="input-text" >
							</div>
							<div>
								<label id="i">Address2</label>
								<input id="hu" type="text" name="Address2"class="input-text">
							</div>
							<div class="form-row">
								<label id="h" class="Postcode">Postcode</label>
								<input id="lu" type="text" name="Postcode" id="Postcode" class="input-text" >
							</div>
                            <div class="form-row form-row-1">
                            	<label id="cr" for="Course">Course</label>
                            	<input  type="text" name="Course" id="course" class="input-text">
                            </div>
                            <div class="form-row">
                            	<label id="dr" class="Date_of_Birth">Date Of Birth</label>
                            	<input id="mu" type="date" name="Date-of-Birth"  class="input-text">
                            </div>
                            </div>
						</div>
						<div class="form-row-last">
							<input id="sa" type="submit" name="register" class="register" value="Register">
							<input id="pa" type="submit" name="Update" class="Update" value="Update">
						</div>

                       	 </div>
					</form>
		</div>
	</section>
<?php } ?>
</body>
</html>